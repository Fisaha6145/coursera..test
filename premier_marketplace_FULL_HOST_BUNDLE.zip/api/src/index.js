import express from 'express';import morgan from 'morgan';import cors from 'cors';import {Pool} from 'pg';import nodemailer from 'nodemailer';
const app=express();app.use(express.json());app.use(morgan('tiny'));app.use(cors({origin:true}));
const pool=new Pool({connectionString:process.env.DATABASE_URL});
(async()=>{await pool.query("CREATE TABLE IF NOT EXISTS early_access_emails(id SERIAL PRIMARY KEY,email TEXT UNIQUE NOT NULL,locale TEXT,created_at TIMESTAMP DEFAULT NOW())");})();
const tx=nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:String(process.env.SMTP_SECURE||'false')==='true',auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}});
app.get('/health',async(_q,res)=>{try{await pool.query('select 1');res.json({ok:true});}catch(e){res.status(500).json({ok:false,error:String(e)})}});
app.post('/api/early-access',async(req,res)=>{try{const {email,locale} = req.body||{}; if(!email||!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.status(400).json({error:'Invalid email'});
await pool.query('INSERT INTO early_access_emails(email,locale) VALUES($1,$2) ON CONFLICT(email) DO NOTHING',[email,locale||'en']);
try{await tx.sendMail({from:process.env.MAIL_FROM||'no-reply@example.com',to:process.env.SMTP_USER||'',subject:'New Early Access signup',text:`Email: ${email} | Locale: ${locale||'en'}`});}catch(e){}
res.json({ok:true});}catch(e){res.status(500).json({error:String(e)})}});
app.listen(3000,()=>console.log('API on :3000'))
