module.exports={experimental:{appDir:true},reactStrictMode:true};
