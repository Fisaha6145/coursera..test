export default function P(){return(<main style={{padding:32}}><meta httpEquiv='refresh' content='0; url=/coming-soon' /></main>)}
